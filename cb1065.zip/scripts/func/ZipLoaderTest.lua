ZipLoader = {}

function ZipLoader.loadZipFile(zipName,fileName)
	local zipFile,err = zip.open(zipName)
	if not zipFile then return nil, err end

	local DstFile,err = zipFile:open(fileName)
	if not DstFile then return nil,err end

	local zipLoader = function()
		return DstFile:read()
	end

	return load(zipLoaderm, "My Lua Zip Load")
end

function ZipLoader.load(zipName,fileName)
	local fun,err = ZipLoader.loadZipFile(zipName,fileName)
	if fun then
		fun()
	else
		print(err)
	end
end

return ZipLoader